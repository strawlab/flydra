from nose.plugins import Plugin

class SomePlugin(Plugin):
    pass
