def test():
    print "something"
    a = 4
    assert a == 2
