Batteries included: builtin nose plugins
========================================

.. toctree ::
   :maxdepth: 2

   allmodules
   attrib
   capture
   collect
   cover
   debug
   deprecated
   doctests
   failuredetail
   isolate
   logcapture
   multiprocess
   prof
   skip
   testid
   xunit
